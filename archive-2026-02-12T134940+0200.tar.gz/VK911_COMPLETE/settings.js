// settings.js - VK911 BOT Configuration
module.exports = Object.freeze({
    BOT_NAME: 'VK911 BOT',
    BOT_EMOJI: '💣',
    BOT_VERSION: '2.0.0',
    AUTHOR: 'GBEXCHANGE †',
    
    CHANNEL_LINK: 'https://whatsapp.com/channel/0029Vb88OB4545unOuID4H0Q',
    YOUTUBE_CHANNEL: 'VK911_TT',
    
    OWNER_NUMBERS: ['2348012345678'],
    OWNER_NAME: 'GBEXCHANGE',
    
    get OWNER_JIDS() {
        return this.OWNER_NUMBERS.map(n => n.replace(/[^0-9]/g, '') + '@s.whatsapp.net');
    },
    
    SESSION_FOLDER: './auth_info',
    USE_PAIRING_CODE: true,
    PREFIX: '.',
    CASE_SENSITIVE_CMDS: false,
    
    AUTO_READ_MESSAGES: true,
    ALWAYS_ONLINE: true,
    SHOW_TYPING_ON_CMD: true,
    
    ENABLE: {
        DOWNLOADERS: true,
        GROUP_TOOLS: true,
        FUN_COMMANDS: true,
        STICKER_TOOLS: true,
        AI_FEATURES: true,
        TEXT_MAKER: true,
    },
    
    get FOOTER() {
        return `
╔═══════════════════════════════════╗
║    ${this.BOT_NAME} • ${this.AUTHOR}    ║
╚═══════════════════════════════════╝

📢 Channel: ${this.CHANNEL_LINK}
🎥 YouTube: ${this.YOUTUBE_CHANNEL}`;
    },
    
    isOwner(jid) {
        if (!jid) return false;
        const number = jid.split('@')[0].replace(/[^0-9]/g, '');
        return this.OWNER_NUMBERS.some(owner => {
            const ownerNum = owner.replace(/[^0-9]/g, '');
            return number === ownerNum;
        });
    }
});
