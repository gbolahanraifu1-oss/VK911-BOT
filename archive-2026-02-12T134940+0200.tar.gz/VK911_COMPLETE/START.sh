#!/bin/bash
echo "╔══════════════════════════════════════════════════╗"
echo "║     VK911 BOT • POWERED BY GBEXCHANGE †          ║"
echo "╚══════════════════════════════════════════════════╝"
echo ""
echo "🚀 Starting VK911 BOT..."
echo ""

# Check Node.js
if ! command -v node &> /dev/null; then
    echo "❌ Node.js not found!"
    echo "Install from: https://nodejs.org/"
    exit 1
fi

echo "✅ Node.js: $(node --version)"

# Install dependencies if needed
if [ ! -d "node_modules" ]; then
    echo "📦 Installing dependencies..."
    npm install
fi

# Start bot
echo ""
node index.js
