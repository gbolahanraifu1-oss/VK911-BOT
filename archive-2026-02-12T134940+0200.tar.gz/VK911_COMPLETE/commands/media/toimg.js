// Sticker to image
const { downloadMediaMessage } = require('@whiskeysockets/baileys');
const sharp = require('sharp');

module.exports = {
    name: 'toimg',
    aliases: ['toimage'],
    category: 'media',
    description: 'Convert sticker to image',
    usage: '.toimg <reply to sticker>',
    cooldown: 5,
    
    async execute(sock, msg, args, { from, settings }) {
        const quoted = msg.message?.extendedTextMessage?.contextInfo?.quotedMessage;
        
        if (!quoted?.stickerMessage) {
            return sock.sendMessage(from, {
                text: `❌ Reply to a sticker!\n\n${settings.FOOTER}`
            });
        }
        
        await sock.sendMessage(from, { text: '⏳ Converting...' });
        
        try {
            const buffer = await downloadMediaMessage({ message: quoted }, 'buffer', {});
            const imgBuffer = await sharp(buffer).png().toBuffer();
            await sock.sendMessage(from, { image: imgBuffer });
        } catch (err) {
            await sock.sendMessage(from, {
                text: `❌ Failed: ${err.message}\n\n${settings.FOOTER}`
            });
        }
    }
};
