// commands/media/meme.js - VK911 BOT
module.exports = {
    name: 'meme',
    aliases: [],
    category: 'media',
    description: 'Random meme',
    usage: '.meme',
    cooldown: 5,
    
    
    
    async execute(sock, msg, args, { from, settings, sender }) {
        const response = `╔══════════════════════════════════════╗
║                RANDOM MEME                 ║
╚══════════════════════════════════════╝

⚠️ This command is under development!
Stay tuned for updates.

${settings.FOOTER}`;
        
        await sock.sendMessage(from, { text: response });
    }
};
