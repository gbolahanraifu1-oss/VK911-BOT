// Sticker maker with Sharp
const { downloadMediaMessage } = require('@whiskeysockets/baileys');
const sharp = require('sharp');

module.exports = {
    name: 'sticker',
    aliases: ['s', 'stiker', 'stick'],
    category: 'media',
    description: 'Convert image/video to sticker',
    usage: '.sticker <reply to image>',
    cooldown: 5,
    
    async execute(sock, msg, args, { from, settings }) {
        const quoted = msg.message?.extendedTextMessage?.contextInfo?.quotedMessage;
        const mediaMsg = quoted || msg.message;
        
        if (!mediaMsg?.imageMessage && !mediaMsg?.videoMessage) {
            return sock.sendMessage(from, { 
                text: `╔══════════════════════════════════════╗
║         📸 STICKER MAKER               ║
╚══════════════════════════════════════╝

❌ Reply to an image or short video!

*Usage:* Reply to media with .sticker

${settings.FOOTER}`
            });
        }
        
        await sock.sendMessage(from, { text: '⏳ Creating sticker...' });
        
        try {
            const buffer = await downloadMediaMessage({ message: mediaMsg }, 'buffer', {});
            const stickerBuffer = await sharp(buffer)
                .resize(512, 512, { fit: 'contain', background: { r: 0, g: 0, b: 0, alpha: 0 } })
                .webp({ quality: 90 })
                .toBuffer();
            
            await sock.sendMessage(from, { sticker: stickerBuffer });
        } catch (err) {
            await sock.sendMessage(from, { 
                text: `❌ Failed: ${err.message}\n\n${settings.FOOTER}` 
            });
        }
    }
};
