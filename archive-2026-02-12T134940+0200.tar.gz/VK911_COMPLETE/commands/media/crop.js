// commands/media/crop.js - VK911 BOT
module.exports = {
    name: 'crop',
    aliases: [],
    category: 'media',
    description: 'Crop image',
    usage: '.crop',
    cooldown: 5,
    
    
    
    async execute(sock, msg, args, { from, settings, sender }) {
        const response = `╔══════════════════════════════════════╗
║                 CROP IMAGE                 ║
╚══════════════════════════════════════╝

⚠️ This command is under development!
Stay tuned for updates.

${settings.FOOTER}`;
        
        await sock.sendMessage(from, { text: response });
    }
};
