// commands/media/tovideo.js - VK911 BOT
module.exports = {
    name: 'tovideo',
    aliases: [],
    category: 'media',
    description: 'Sticker to video',
    usage: '.tovideo',
    cooldown: 5,
    
    
    
    async execute(sock, msg, args, { from, settings, sender }) {
        const response = `╔══════════════════════════════════════╗
║              STICKER TO VIDEO              ║
╚══════════════════════════════════════╝

⚠️ This command is under development!
Stay tuned for updates.

${settings.FOOTER}`;
        
        await sock.sendMessage(from, { text: response });
    }
};
