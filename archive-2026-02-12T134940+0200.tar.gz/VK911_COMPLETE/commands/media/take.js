// commands/media/take.js - VK911 BOT
module.exports = {
    name: 'take',
    aliases: ['steal'],
    category: 'media',
    description: 'Steal sticker',
    usage: '.take',
    cooldown: 5,
    
    
    
    async execute(sock, msg, args, { from, settings, sender }) {
        const response = `╔══════════════════════════════════════╗
║               STEAL STICKER                ║
╚══════════════════════════════════════╝

⚠️ This command is under development!
Stay tuned for updates.

${settings.FOOTER}`;
        
        await sock.sendMessage(from, { text: response });
    }
};
