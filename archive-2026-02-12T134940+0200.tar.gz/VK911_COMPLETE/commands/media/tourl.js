// commands/media/tourl.js - VK911 BOT
module.exports = {
    name: 'tourl',
    aliases: [],
    category: 'media',
    description: 'Media to URL',
    usage: '.tourl',
    cooldown: 5,
    
    
    
    async execute(sock, msg, args, { from, settings, sender }) {
        const response = `╔══════════════════════════════════════╗
║                MEDIA TO URL                ║
╚══════════════════════════════════════╝

⚠️ This command is under development!
Stay tuned for updates.

${settings.FOOTER}`;
        
        await sock.sendMessage(from, { text: response });
    }
};
