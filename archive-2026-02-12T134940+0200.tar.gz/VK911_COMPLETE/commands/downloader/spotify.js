// commands/downloader/spotify.js - VK911 BOT
module.exports = {
    name: 'spotify',
    aliases: [],
    category: 'downloader',
    description: 'Spotify download',
    usage: '.spotify',
    cooldown: 5,
    
    
    
    async execute(sock, msg, args, { from, settings, sender }) {
        const response = `╔══════════════════════════════════════╗
║              SPOTIFY DOWNLOAD              ║
╚══════════════════════════════════════╝

⚠️ This command is under development!
Stay tuned for updates.

${settings.FOOTER}`;
        
        await sock.sendMessage(from, { text: response });
    }
};
