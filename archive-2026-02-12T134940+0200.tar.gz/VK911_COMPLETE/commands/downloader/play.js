// commands/downloader/play.js - VK911 BOT
module.exports = {
    name: 'play',
    aliases: [],
    category: 'downloader',
    description: 'Play music',
    usage: '.play',
    cooldown: 5,
    
    
    
    async execute(sock, msg, args, { from, settings, sender }) {
        const response = `╔══════════════════════════════════════╗
║                 PLAY MUSIC                 ║
╚══════════════════════════════════════╝

⚠️ This command is under development!
Stay tuned for updates.

${settings.FOOTER}`;
        
        await sock.sendMessage(from, { text: response });
    }
};
