// commands/fun/simp.js - VK911 BOT
module.exports = {
    name: 'simp',
    aliases: [],
    category: 'fun',
    description: 'Simp rate',
    usage: '.simp',
    cooldown: 5,
    
    
    
    async execute(sock, msg, args, { from, settings, sender }) {
        const response = `╔══════════════════════════════════════╗
║                 SIMP RATE                  ║
╚══════════════════════════════════════╝

⚠️ This command is under development!
Stay tuned for updates.

${settings.FOOTER}`;
        
        await sock.sendMessage(from, { text: response });
    }
};
