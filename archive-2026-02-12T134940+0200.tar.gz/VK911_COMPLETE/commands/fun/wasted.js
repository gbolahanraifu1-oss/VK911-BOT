// commands/fun/wasted.js - VK911 BOT
module.exports = {
    name: 'wasted',
    aliases: [],
    category: 'fun',
    description: 'Wasted meme',
    usage: '.wasted',
    cooldown: 5,
    
    
    
    async execute(sock, msg, args, { from, settings, sender }) {
        const response = `╔══════════════════════════════════════╗
║                WASTED MEME                 ║
╚══════════════════════════════════════╝

⚠️ This command is under development!
Stay tuned for updates.

${settings.FOOTER}`;
        
        await sock.sendMessage(from, { text: response });
    }
};
