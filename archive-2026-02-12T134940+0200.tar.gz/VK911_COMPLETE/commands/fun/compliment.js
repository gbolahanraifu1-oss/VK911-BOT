// commands/fun/compliment.js - VK911 BOT
module.exports = {
    name: 'compliment',
    aliases: [],
    category: 'fun',
    description: 'Compliment someone',
    usage: '.compliment',
    cooldown: 5,
    
    
    
    async execute(sock, msg, args, { from, settings, sender }) {
        const response = `╔══════════════════════════════════════╗
║             COMPLIMENT SOMEONE             ║
╚══════════════════════════════════════╝

⚠️ This command is under development!
Stay tuned for updates.

${settings.FOOTER}`;
        
        await sock.sendMessage(from, { text: response });
    }
};
