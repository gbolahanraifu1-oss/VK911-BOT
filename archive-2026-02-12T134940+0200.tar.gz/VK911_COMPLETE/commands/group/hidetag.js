// commands/group/hidetag.js - VK911 BOT
module.exports = {
    name: 'hidetag',
    aliases: [],
    category: 'group',
    description: 'Hidden tag',
    usage: '.hidetag',
    cooldown: 5,
    
    groupOnly: true,
    
    async execute(sock, msg, args, { from, settings, sender }) {
        const response = `╔══════════════════════════════════════╗
║                 HIDDEN TAG                 ║
╚══════════════════════════════════════╝

⚠️ This command is under development!
Stay tuned for updates.

${settings.FOOTER}`;
        
        await sock.sendMessage(from, { text: response });
    }
};
