// Kick member
module.exports = {
    name: 'kick',
    aliases: ['remove'],
    category: 'group',
    description: 'Kick member from group',
    usage: '.kick @user',
    groupOnly: true,
    cooldown: 3,
    
    async execute(sock, msg, args, { from, settings }) {
        const groupMetadata = await sock.groupMetadata(from);
        const participants = groupMetadata.participants;
        const botNumber = sock.user.id.split(':')[0] + '@s.whatsapp.net';
        
        const botAdmin = participants.find(p => p.id === botNumber)?.admin;
        if (!botAdmin) {
            return sock.sendMessage(from, { 
                text: `❌ I need admin rights!\n\n${settings.FOOTER}`
            });
        }
        
        const quoted = msg.message?.extendedTextMessage?.contextInfo;
        const target = quoted?.participant || quoted?.mentionedJid?.[0];
        
        if (!target) {
            return sock.sendMessage(from, { 
                text: `╔══════════════════════════════════════╗
║           👢 KICK MEMBER               ║
╚══════════════════════════════════════╝

*Usage:* Reply to user or @mention them

${settings.FOOTER}`
            });
        }
        
        await sock.groupParticipantsUpdate(from, [target], 'remove');
        await sock.sendMessage(from, { 
            text: `✅ Kicked @${target.split('@')[0]}!`,
            mentions: [target]
        });
    }
};
