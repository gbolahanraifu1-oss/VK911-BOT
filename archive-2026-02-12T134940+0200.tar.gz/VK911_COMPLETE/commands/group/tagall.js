// Tag all members
module.exports = {
    name: 'tagall',
    aliases: ['everyone', 'all'],
    category: 'group',
    description: 'Tag all members',
    usage: '.tagall [message]',
    groupOnly: true,
    cooldown: 10,
    
    async execute(sock, msg, args, { from, settings }) {
        const groupMetadata = await sock.groupMetadata(from);
        const participants = groupMetadata.participants;
        const mentions = participants.map(p => p.id);
        
        const message = args.join(' ') || 'Attention everyone!';
        
        let text = `╔══════════════════════════════════════╗
║       📢 GROUP ANNOUNCEMENT            ║
╚══════════════════════════════════════╝

${message}

━━━━━━━━ TAGGED (${participants.length}) ━━━━━━━━

`;
        
        participants.forEach((p, i) => {
            text += `${i + 1}. @${p.id.split('@')[0]}\n`;
        });
        
        text += `\n${settings.FOOTER}`;
        
        await sock.sendMessage(from, { text, mentions });
    }
};
