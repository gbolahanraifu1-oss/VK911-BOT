// commands/group/antilink.js - VK911 BOT
module.exports = {
    name: 'antilink',
    aliases: [],
    category: 'group',
    description: 'Toggle antilink',
    usage: '.antilink',
    cooldown: 5,
    
    groupOnly: true,
    
    async execute(sock, msg, args, { from, settings, sender }) {
        const response = `╔══════════════════════════════════════╗
║              TOGGLE ANTILINK               ║
╚══════════════════════════════════════╝

⚠️ This command is under development!
Stay tuned for updates.

${settings.FOOTER}`;
        
        await sock.sendMessage(from, { text: response });
    }
};
