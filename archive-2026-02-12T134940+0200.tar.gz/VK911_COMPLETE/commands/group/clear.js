// commands/group/clear.js - VK911 BOT
module.exports = {
    name: 'clear',
    aliases: ['purge'],
    category: 'group',
    description: 'Clear messages',
    usage: '.clear',
    cooldown: 5,
    
    groupOnly: true,
    
    async execute(sock, msg, args, { from, settings, sender }) {
        const response = `╔══════════════════════════════════════╗
║               CLEAR MESSAGES               ║
╚══════════════════════════════════════╝

⚠️ This command is under development!
Stay tuned for updates.

${settings.FOOTER}`;
        
        await sock.sendMessage(from, { text: response });
    }
};
