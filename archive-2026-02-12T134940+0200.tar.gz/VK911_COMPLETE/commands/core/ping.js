// Ping command with full stats
const os = require('os');

module.exports = {
    name: 'ping',
    aliases: ['p', 'latency', 'speed'],
    category: 'core',
    description: 'Check bot response time',
    usage: '.ping',
    cooldown: 5,

    async execute(sock, msg, args, { from, settings }) {
        const start = Date.now();
        const sent = await sock.sendMessage(from, { text: '🏓 Pinging...' });
        const latency = Date.now() - start;
        
        const totalMem = (os.totalmem() / 1024 / 1024 / 1024).toFixed(2);
        const freeMem = (os.freemem() / 1024 / 1024 / 1024).toFixed(2);
        const usedMem = (totalMem - freeMem).toFixed(2);
        const memUsage = ((usedMem / totalMem) * 100).toFixed(1);
        
        const uptime = process.uptime();
        const days = Math.floor(uptime / 86400);
        const hours = Math.floor((uptime % 86400) / 3600);
        const minutes = Math.floor((uptime % 3600) / 60);
        
        let speedEmoji = '🟢';
        let speedText = 'Excellent';
        if (latency > 100 && latency <= 300) {
            speedEmoji = '🟡';
            speedText = 'Good';
        } else if (latency > 300) {
            speedEmoji = '🔴';
            speedText = 'Slow';
        }
        
        await sock.sendMessage(from, {
            text: `╔══════════════════════════════════════╗
║       🏓 PONG! - ${settings.BOT_NAME}       ║
╚══════════════════════════════════════╝

${speedEmoji} *Response:* ${latency}ms
⚡ *Speed:* ${speedText}

━━━━━━━ SYSTEM STATUS ━━━━━━━

🖥️ *CPU:* ${os.loadavg()[0].toFixed(2)}%
💾 *RAM:* ${usedMem}GB / ${totalMem}GB (${memUsage}%)
⏱️ *Uptime:* ${days}d ${hours}h ${minutes}m
📱 *Platform:* ${os.platform()}

${settings.FOOTER}`,
            edit: sent.key
        });
    }
};
