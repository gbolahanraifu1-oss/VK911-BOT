// Menu command
const fs = require('fs');
const path = require('path');

module.exports = {
    name: 'menu',
    aliases: ['help', 'commands'],
    category: 'core',
    description: 'Show all commands',
    usage: '.menu [category]',
    cooldown: 5,

    async execute(sock, msg, args, { from, settings }) {
        const categories = {};
        const cmdBase = path.join(__dirname, '../..');
        
        function scanCommands(dir) {
            const fullPath = path.join(cmdBase, 'commands', dir);
            if (!fs.existsSync(fullPath)) return;
            fs.readdirSync(fullPath).forEach(file => {
                if (!file.endsWith('.js')) return;
                try {
                    const cmd = require(path.join(fullPath, file));
                    if (!cmd.name) return;
                    if (!categories[dir]) categories[dir] = [];
                    categories[dir].push(cmd.name);
                } catch (e) {}
            });
        }
        
        ['core', 'group', 'media', 'downloader', 'fun', 'ai', 'textmaker', 'search', 'tools', 'owner'].forEach(cat => {
            scanCommands(cat);
        });
        
        let total = 0;
        Object.values(categories).forEach(cmds => total += cmds.length);
        
        const menuText = `╔══════════════════════════════════════╗
║     ${settings.BOT_NAME} MENU            ║
╚══════════════════════════════════════╝

💎 *Total:* ${total}+ Commands
⚡ *Prefix:* ${settings.PREFIX}

━━━━━━━━ CATEGORIES ━━━━━━━━

${Object.keys(categories).map(cat => {
    const emoji = {
        core: '⭐', group: '👥', media: '🎨',
        downloader: '📥', fun: '🎮', ai: '🤖',
        textmaker: '✨', search: '🔍', tools: '🔧',
        owner: '👑'
    }[cat] || '📂';
    return `${emoji} *${cat.toUpperCase()}* (${categories[cat].length})\n${categories[cat].slice(0, 6).join(', ')}${categories[cat].length > 6 ? '...' : ''}`;
}).join('\n\n')}

━━━━━━━━━━━━━━━━━━━━━━━━━━━━

${settings.FOOTER}`;

        await sock.sendMessage(from, { text: menuText });
    }
};
