// commands/core/joke.js - VK911 BOT
module.exports = {
    name: 'joke',
    aliases: [],
    category: 'core',
    description: 'Random joke',
    usage: '.joke',
    cooldown: 5,
    
    
    
    async execute(sock, msg, args, { from, settings, sender }) {
        const response = `╔══════════════════════════════════════╗
║                RANDOM JOKE                 ║
╚══════════════════════════════════════╝

⚠️ This command is under development!
Stay tuned for updates.

${settings.FOOTER}`;
        
        await sock.sendMessage(from, { text: response });
    }
};
