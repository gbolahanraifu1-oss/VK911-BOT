// commands/core/8ball.js - VK911 BOT
module.exports = {
    name: '8ball',
    aliases: ['magic8'],
    category: 'core',
    description: 'Magic 8 ball',
    usage: '.8ball',
    cooldown: 5,
    
    
    
    async execute(sock, msg, args, { from, settings, sender }) {
        const response = `╔══════════════════════════════════════╗
║                MAGIC 8 BALL                ║
╚══════════════════════════════════════╝

⚠️ This command is under development!
Stay tuned for updates.

${settings.FOOTER}`;
        
        await sock.sendMessage(from, { text: response });
    }
};
