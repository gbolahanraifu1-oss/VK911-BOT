// commands/core/owner.js - VK911 BOT
module.exports = {
    name: 'owner',
    aliases: ['creator', 'dev'],
    category: 'core',
    description: 'Get owner contact',
    usage: '.owner',
    cooldown: 5,
    
    
    
    async execute(sock, msg, args, { from, settings, sender }) {
        const response = `╔══════════════════════════════════════╗
║             GET OWNER CONTACT              ║
╚══════════════════════════════════════╝

⚠️ This command is under development!
Stay tuned for updates.

${settings.FOOTER}`;
        
        await sock.sendMessage(from, { text: response });
    }
};
