// commands/core/attp.js - VK911 BOT
module.exports = {
    name: 'attp',
    aliases: [],
    category: 'core',
    description: 'Animated text',
    usage: '.attp',
    cooldown: 5,
    
    
    
    async execute(sock, msg, args, { from, settings, sender }) {
        const response = `╔══════════════════════════════════════╗
║               ANIMATED TEXT                ║
╚══════════════════════════════════════╝

⚠️ This command is under development!
Stay tuned for updates.

${settings.FOOTER}`;
        
        await sock.sendMessage(from, { text: response });
    }
};
