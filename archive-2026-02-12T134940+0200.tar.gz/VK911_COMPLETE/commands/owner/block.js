// commands/owner/block.js - VK911 BOT
module.exports = {
    name: 'block',
    aliases: [],
    category: 'owner',
    description: 'Block user',
    usage: '.block',
    cooldown: 5,
    ownerOnly: true,
    
    
    async execute(sock, msg, args, { from, settings, sender }) {
        const response = `╔══════════════════════════════════════╗
║                 BLOCK USER                 ║
╚══════════════════════════════════════╝

⚠️ This command is under development!
Stay tuned for updates.

${settings.FOOTER}`;
        
        await sock.sendMessage(from, { text: response });
    }
};
