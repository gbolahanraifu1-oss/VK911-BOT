// commands/search/google.js - VK911 BOT
module.exports = {
    name: 'google',
    aliases: ['search'],
    category: 'search',
    description: 'Google search',
    usage: '.google',
    cooldown: 5,
    
    
    
    async execute(sock, msg, args, { from, settings, sender }) {
        const response = `╔══════════════════════════════════════╗
║               GOOGLE SEARCH                ║
╚══════════════════════════════════════╝

⚠️ This command is under development!
Stay tuned for updates.

${settings.FOOTER}`;
        
        await sock.sendMessage(from, { text: response });
    }
};
