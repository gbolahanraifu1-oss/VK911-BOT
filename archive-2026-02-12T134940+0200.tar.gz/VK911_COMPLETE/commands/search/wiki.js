// commands/search/wiki.js - VK911 BOT
module.exports = {
    name: 'wiki',
    aliases: ['wikipedia'],
    category: 'search',
    description: 'Wikipedia search',
    usage: '.wiki',
    cooldown: 5,
    
    
    
    async execute(sock, msg, args, { from, settings, sender }) {
        const response = `╔══════════════════════════════════════╗
║              WIKIPEDIA SEARCH              ║
╚══════════════════════════════════════╝

⚠️ This command is under development!
Stay tuned for updates.

${settings.FOOTER}`;
        
        await sock.sendMessage(from, { text: response });
    }
};
