// commands/search/image.js - VK911 BOT
module.exports = {
    name: 'image',
    aliases: ['img'],
    category: 'search',
    description: 'Image search',
    usage: '.image',
    cooldown: 5,
    
    
    
    async execute(sock, msg, args, { from, settings, sender }) {
        const response = `╔══════════════════════════════════════╗
║                IMAGE SEARCH                ║
╚══════════════════════════════════════╝

⚠️ This command is under development!
Stay tuned for updates.

${settings.FOOTER}`;
        
        await sock.sendMessage(from, { text: response });
    }
};
