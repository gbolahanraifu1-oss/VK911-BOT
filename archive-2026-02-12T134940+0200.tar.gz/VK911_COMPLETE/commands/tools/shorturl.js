// commands/tools/shorturl.js - VK911 BOT
module.exports = {
    name: 'shorturl',
    aliases: ['short'],
    category: 'tools',
    description: 'Shorten URL',
    usage: '.shorturl',
    cooldown: 5,
    
    
    
    async execute(sock, msg, args, { from, settings, sender }) {
        const response = `╔══════════════════════════════════════╗
║                SHORTEN URL                 ║
╚══════════════════════════════════════╝

⚠️ This command is under development!
Stay tuned for updates.

${settings.FOOTER}`;
        
        await sock.sendMessage(from, { text: response });
    }
};
