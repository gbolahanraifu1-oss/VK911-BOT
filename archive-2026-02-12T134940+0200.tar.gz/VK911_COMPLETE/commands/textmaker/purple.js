// commands/textmaker/purple.js - VK911 BOT
module.exports = {
    name: 'purple',
    aliases: [],
    category: 'textmaker',
    description: 'Purple text',
    usage: '.purple',
    cooldown: 5,
    
    
    
    async execute(sock, msg, args, { from, settings, sender }) {
        const response = `╔══════════════════════════════════════╗
║                PURPLE TEXT                 ║
╚══════════════════════════════════════╝

⚠️ This command is under development!
Stay tuned for updates.

${settings.FOOTER}`;
        
        await sock.sendMessage(from, { text: response });
    }
};
