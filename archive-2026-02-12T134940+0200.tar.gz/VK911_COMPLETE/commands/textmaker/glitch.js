// commands/textmaker/glitch.js - VK911 BOT
module.exports = {
    name: 'glitch',
    aliases: [],
    category: 'textmaker',
    description: 'Glitch text',
    usage: '.glitch',
    cooldown: 5,
    
    
    
    async execute(sock, msg, args, { from, settings, sender }) {
        const response = `╔══════════════════════════════════════╗
║                GLITCH TEXT                 ║
╚══════════════════════════════════════╝

⚠️ This command is under development!
Stay tuned for updates.

${settings.FOOTER}`;
        
        await sock.sendMessage(from, { text: response });
    }
};
