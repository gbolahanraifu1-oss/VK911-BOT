// commands/textmaker/arena.js - VK911 BOT
module.exports = {
    name: 'arena',
    aliases: [],
    category: 'textmaker',
    description: 'Arena text',
    usage: '.arena',
    cooldown: 5,
    
    
    
    async execute(sock, msg, args, { from, settings, sender }) {
        const response = `╔══════════════════════════════════════╗
║                 ARENA TEXT                 ║
╚══════════════════════════════════════╝

⚠️ This command is under development!
Stay tuned for updates.

${settings.FOOTER}`;
        
        await sock.sendMessage(from, { text: response });
    }
};
