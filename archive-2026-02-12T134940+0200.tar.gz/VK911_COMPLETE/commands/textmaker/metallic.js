// commands/textmaker/metallic.js - VK911 BOT
module.exports = {
    name: 'metallic',
    aliases: [],
    category: 'textmaker',
    description: 'Metallic text',
    usage: '.metallic',
    cooldown: 5,
    
    
    
    async execute(sock, msg, args, { from, settings, sender }) {
        const response = `╔══════════════════════════════════════╗
║               METALLIC TEXT                ║
╚══════════════════════════════════════╝

⚠️ This command is under development!
Stay tuned for updates.

${settings.FOOTER}`;
        
        await sock.sendMessage(from, { text: response });
    }
};
