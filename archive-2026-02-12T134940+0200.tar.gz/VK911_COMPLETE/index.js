// index.js - VK911 BOT Main Entry Point
// Author: GBEXCHANGE †
// Multi-Device with Pairing Code

const makeWASocket = require('@whiskeysockets/baileys').default;
const {
    useMultiFileAuthState,
    DisconnectReason,
    fetchLatestBaileysVersion,
    makeCacheableSignalKeyStore,
    Browsers
} = require('@whiskeysockets/baileys');

const pino = require('pino');
const readline = require('readline');
const fs = require('fs');
const path = require('path');
const chalk = require('chalk');
const gradient = require('gradient-string');
const figlet = require('figlet');

const settings = require('./settings');

// ═══════════════════════════════════════════════════════
// BANNER
// ═══════════════════════════════════════════════════════
console.clear();
const banner = figlet.textSync('VK911 BOT', { font: 'ANSI Shadow' });
console.log(gradient.pastel(banner));
console.log(chalk.bold.hex('#FF0080')('\n╔══════════════════════════════════════════════════╗'));
console.log(chalk.bold.hex('#FF0080')('║') + chalk.bold.white('        VK911 BOT • POWERED BY GBEXCHANGE †       ') + chalk.bold.hex('#FF0080')('║'));
console.log(chalk.bold.hex('#FF0080')('╚══════════════════════════════════════════════════╝'));
console.log(chalk.cyan(`\n✨ Version: ${settings.BOT_VERSION}`));
console.log(chalk.cyan(`📱 Multi-Device: Enabled`));
console.log(chalk.cyan(`🔐 Pairing: Pairing Code`));
console.log(chalk.cyan(`👑 Owner: ${settings.OWNER_NAME}\n`));

const rl = readline.createInterface({ 
    input: process.stdin, 
    output: process.stdout 
});

const commands = new Map();
const cooldowns = new Map();

function loadCommands() {
    const cmdBase = path.join(__dirname, 'commands');
    if (!fs.existsSync(cmdBase)) {
        console.log(chalk.yellow('⚠️  Commands folder not found!'));
        return;
    }

    function loadFolder(dir) {
        fs.readdirSync(dir, { withFileTypes: true }).forEach(entry => {
            const full = path.join(dir, entry.name);
            if (entry.isDirectory()) {
                return loadFolder(full);
            }
            if (!entry.name.endsWith('.js')) return;

            try {
                delete require.cache[require.resolve(full)];
                const cmd = require(full);
                if (!cmd.name) return;
                
                const key = settings.CASE_SENSITIVE_CMDS ? cmd.name : cmd.name.toLowerCase();
                commands.set(key, cmd);
                
                if (cmd.aliases && Array.isArray(cmd.aliases)) {
                    cmd.aliases.forEach(alias => {
                        const ak = settings.CASE_SENSITIVE_CMDS ? alias : alias.toLowerCase();
                        commands.set(ak, cmd);
                    });
                }
            } catch (err) {
                console.error(chalk.red(`✗ Failed to load ${entry.name}:`), err.message);
            }
        });
    }

    loadFolder(cmdBase);
    console.log(chalk.bold.green(`\n🎯 Total Commands Loaded: ${commands.size}\n`));
}

async function connectBot() {
    const { state, saveCreds } = await useMultiFileAuthState(settings.SESSION_FOLDER);
    const { version } = await fetchLatestBaileysVersion();

    const sock = makeWASocket({
        version,
        logger: pino({ level: 'silent' }),
        printQRInTerminal: false,
        browser: Browsers.macOS('Desktop'),
        auth: {
            creds: state.creds,
            keys: makeCacheableSignalKeyStore(state.keys, pino({ level: 'silent' }))
        },
        getMessage: async (key) => {
            return { conversation: 'VK911 BOT' };
        },
        syncFullHistory: false,
        shouldSyncHistoryMessage: () => false,
        markOnlineOnConnect: settings.ALWAYS_ONLINE
    });

    sock.ev.on('creds.update', saveCreds);

    sock.ev.on('connection.update', (update) => {
        const { connection, lastDisconnect } = update;

        if (connection === 'close') {
            const shouldReconnect = lastDisconnect?.error?.output?.statusCode !== DisconnectReason.loggedOut;
            console.log(chalk.red('❌ Connection closed!'), shouldReconnect ? chalk.yellow('→ Reconnecting...') : '');
            if (shouldReconnect) {
                setTimeout(connectBot, 3000);
            }
        }

        if (connection === 'open') {
            console.log(chalk.bold.hex('#00FF00')('\n╔══════════════════════════════════════════════════╗'));
            console.log(chalk.bold.hex('#00FF00')('║') + chalk.bold.white('           🔥 VK911 BOT IS NOW ONLINE! 🔥         ') + chalk.bold.hex('#00FF00')('║'));
            console.log(chalk.bold.hex('#00FF00')('╚══════════════════════════════════════════════════╝\n'));
            
            if (settings.OWNER_JIDS.length > 0) {
                const startMsg = `╔══════════════════════════════════════╗
║       🔥 VK911 BOT ONLINE! 🔥        ║
╚══════════════════════════════════════╝

✨ Bot successfully started!
📱 Multi-Device: Enabled
🎯 Commands: ${commands.size}+
⚡ Status: Fully Operational

${settings.FOOTER}`;
                
                sock.sendMessage(settings.OWNER_JIDS[0], { 
                    text: startMsg 
                }).catch(() => {});
            }
        }
    });

    if (settings.USE_PAIRING_CODE && !state.creds.registered) {
        let phoneNumber = null;
        
        if (process.argv.includes('--pair')) {
            phoneNumber = process.argv[process.argv.indexOf('--pair') + 1];
        }
        
        if (!phoneNumber) {
            phoneNumber = await new Promise(resolve => {
                console.log(chalk.bold.cyan('\n╔══════════════════════════════════════════════════╗'));
                console.log(chalk.bold.cyan('║          PAIRING CODE ACTIVATION                 ║'));
                console.log(chalk.bold.cyan('╚══════════════════════════════════════════════════╝\n'));
                rl.question(chalk.yellow('📱 Enter phone number (e.g., 2348012345678): '), resolve);
            });
        }
        
        phoneNumber = phoneNumber.replace(/[^0-9]/g, '');
        
        if (phoneNumber.length < 10) {
            console.log(chalk.red('\n❌ Invalid phone number!'));
            process.exit(1);
        }

        try {
            const code = await sock.requestPairingCode(phoneNumber);
            
            console.log(chalk.bold.hex('#FF0080')('\n╔══════════════════════════════════════════════════╗'));
            console.log(chalk.bold.hex('#FF0080')('║              YOUR PAIRING CODE                   ║'));
            console.log(chalk.bold.hex('#FF0080')('╚══════════════════════════════════════════════════╝\n'));
            
            console.log(chalk.bold.hex('#00FF00')(`        📱 Phone: ${phoneNumber}`));
            console.log(chalk.bold.hex('#00FF00')(`        🔑 Code:  ${chalk.bold.bgMagenta.white(` ${code} `)}\n`));
            
            console.log(chalk.yellow('╔══════════════════════════════════════════════════╗'));
            console.log(chalk.yellow('║              PAIRING INSTRUCTIONS                ║'));
            console.log(chalk.yellow('╚══════════════════════════════════════════════════╝\n'));
            console.log(chalk.cyan('1️⃣  Open WhatsApp on your phone'));
            console.log(chalk.cyan('2️⃣  Go to: Settings → Linked Devices'));
            console.log(chalk.cyan('3️⃣  Tap: Link a Device'));
            console.log(chalk.cyan('4️⃣  Tap: Link with Phone Number'));
            console.log(chalk.cyan(`5️⃣  Enter this code: ${chalk.bold.white(code)}\n`));
            
        } catch (err) {
            console.error(chalk.red('\n❌ Pairing failed:'), err.message);
            process.exit(1);
        }
    }

    loadCommands();

    sock.ev.on('messages.upsert', async ({ messages, type }) => {
        if (type !== 'notify') return;
        
        const msg = messages[0];
        if (!msg.message) return;
        if (msg.key.fromMe) return;

        const from = msg.key.remoteJid;
        const sender = msg.key.participant || from;
        const isGroup = from.endsWith('@g.us');
        
        const body = msg.message.conversation ||
                     msg.message.extendedTextMessage?.text ||
                     msg.message.imageMessage?.caption ||
                     msg.message.videoMessage?.caption || '';

        if (!body.startsWith(settings.PREFIX)) return;

        const args = body.slice(settings.PREFIX.length).trim().split(/ +/);
        const cmdNameRaw = args.shift() || '';
        const cmdName = settings.CASE_SENSITIVE_CMDS ? cmdNameRaw : cmdNameRaw.toLowerCase();

        const cmd = commands.get(cmdName);
        if (!cmd) return;

        if (cmd.ownerOnly && !settings.isOwner(sender)) {
            return sock.sendMessage(from, { 
                text: `🔒 Owner command only\n\n${settings.FOOTER}`
            });
        }

        if (cmd.groupOnly && !isGroup) {
            return sock.sendMessage(from, { 
                text: `👥 Group command only\n\n${settings.FOOTER}`
            });
        }

        if (!cooldowns.has(cmdName)) {
            cooldowns.set(cmdName, new Map());
        }

        const now = Date.now();
        const timestamps = cooldowns.get(cmdName);
        const cooldownAmount = (cmd.cooldown || 3) * 1000;

        if (timestamps.has(sender)) {
            const expirationTime = timestamps.get(sender) + cooldownAmount;
            if (now < expirationTime) {
                const timeLeft = ((expirationTime - now) / 1000).toFixed(1);
                return sock.sendMessage(from, { 
                    text: `⏳ Wait ${timeLeft}s` 
                });
            }
        }

        timestamps.set(sender, now);
        setTimeout(() => timestamps.delete(sender), cooldownAmount);

        if (settings.SHOW_TYPING_ON_CMD) {
            await sock.sendPresenceUpdate('composing', from);
        }

        try {
            await cmd.execute(sock, msg, args, {
                from,
                sender,
                isGroup,
                isOwner: settings.isOwner(sender),
                settings,
                command: cmdName
            });
        } catch (err) {
            console.error(chalk.red(`❌ Command error [${cmdName}]:`), err);
            await sock.sendMessage(from, { 
                text: `❌ Command failed: ${err.message}\n\n${settings.FOOTER}`
            });
        } finally {
            if (settings.AUTO_READ_MESSAGES) {
                await sock.readMessages([msg.key]).catch(() => {});
            }
            await sock.sendPresenceUpdate('available', from);
        }
    });

    return sock;
}

connectBot().catch(err => {
    console.error(chalk.red.bold('\n💥 CRITICAL ERROR:'), err);
    process.exit(1);
});
