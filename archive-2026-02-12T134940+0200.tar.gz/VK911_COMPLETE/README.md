# VK911 BOT • POWERED BY GBEXCHANGE †

> **The Ultimate WhatsApp Multi-Device Bot with 100+ Commands**

## 🚀 Features

✅ **100+ Commands** across 10 categories
✅ **Pairing Code** - No QR scanning needed!
✅ **Multi-Device Support** - Link multiple devices
✅ **CPU Optimized** - Runs smoothly on low-end servers
✅ **Professional Design** - Bold, beautiful outputs
✅ **Auto Channel Promo** - Your channel in every response

## 📋 Categories

| Category | Commands | Description |
|----------|----------|-------------|
| ⭐ **Core** | 16 | Essential bot commands |
| 👥 **Group** | 16 | Group management & moderation |
| 🎨 **Media** | 12 | Stickers, images, effects |
| 📥 **Downloader** | 8 | YouTube, TikTok, Instagram, etc. |
| 🎮 **Fun** | 14 | Games & entertainment |
| 🤖 **AI** | 1 | AI chat & generation |
| ✨ **Textmaker** | 17 | Text logo effects |
| 🔍 **Search** | 4 | Google, images, wiki |
| 🔧 **Tools** | 5 | Calculator, QR, translator |
| 👑 **Owner** | 5 | Owner-only commands |

## ⚡ Quick Start

### 1. Install Node.js
Download Node.js v18+ from: https://nodejs.org/

### 2. Install Dependencies
```bash
cd VK911_COMPLETE
npm install
```

### 3. Configure
Edit `settings.js`:
```javascript
OWNER_NUMBERS: ['234XXXXXXXXXX'],  // Your number
CHANNEL_LINK: 'https://whatsapp.com/channel/...',
```

### 4. Start Bot
```bash
npm start
```

### 5. Pair Your Device
When prompted:
1. Enter your phone number (e.g., 2348012345678)
2. You'll receive an 8-digit pairing code
3. Open WhatsApp → Settings → Linked Devices
4. Tap "Link with Phone Number"
5. Enter the pairing code

✅ **Bot is now online!**

## 📱 Pairing Code Method

Instead of scanning QR codes, VK911 BOT uses **Pairing Codes**:

```
╔══════════════════════════════════════════════════╗
║              YOUR PAIRING CODE                   ║
╚══════════════════════════════════════════════════╝

        📱 Phone: 2348012345678
        🔑 Code:  AB12-CD34
```

**Benefits:**
- ✅ No need for camera/scanner
- ✅ Works on headless servers
- ✅ More secure
- ✅ Easier for remote setup

## 🎯 Usage Examples

### Basic Commands
```
.ping          - Check bot speed
.menu          - Show all commands
.alive         - Check bot status
.owner         - Get owner contact
```

### Group Management
```
.kick @user    - Kick member
.tagall        - Tag everyone
.promote @user - Make admin
.antilink      - Toggle link protection
```

### Media Commands
```
.sticker       - Make sticker (reply to image)
.toimg         - Sticker to image
.emojimix 😊+😎 - Mix emojis
.rembg         - Remove background
```

### Downloaders
```
.yt <url>      - YouTube download
.tiktok <url>  - TikTok download
.ig <url>      - Instagram download
```

### Fun
```
.roast @user   - Roast someone
.ship @a @b    - Ship calculator
.truth         - Truth question
.dare          - Dare challenge
```

## ⚙️ Configuration

All settings in `settings.js`:

```javascript
// Bot Identity
BOT_NAME: 'VK911 BOT'
BOT_VERSION: '2.0.0'
AUTHOR: 'GBEXCHANGE †'

// Your Info
CHANNEL_LINK: 'https://whatsapp.com/channel/...'
YOUTUBE_CHANNEL: 'VK911_TT'
OWNER_NUMBERS: ['234XXXXXXXXXX']

// Behavior
PREFIX: '.'
AUTO_READ_MESSAGES: true
ALWAYS_ONLINE: true
```

## 🔧 Troubleshooting

### "Cannot find package '@whiskeysockets/baileys'"
**Fix:** Run `npm install`

### "Pairing code not working"
**Fix:** Make sure you enter the code within 60 seconds

### "Bot not responding"
**Fix:** Check if bot has admin rights (for group commands)

## 📊 System Requirements

- **Node.js:** v18 or higher
- **RAM:** 512MB minimum
- **Storage:** 1GB for dependencies
- **Internet:** Required

## 🚀 Deployment

### Local (Windows/Mac/Linux)
```bash
npm start
```

### VPS/Server
```bash
npm install -g pm2
pm2 start index.js --name vk911
pm2 startup
pm2 save
```

### Pterodactyl Panel
1. Upload files via SFTP or File Manager
2. In panel: Set startup command to `node index.js`
3. In "Additional Node Packages": Add package names
4. Restart server

### Heroku/Railway/Render
These platforms auto-install dependencies. Just deploy!

## 📁 File Structure

```
VK911_COMPLETE/
├── index.js              # Main entry point
├── settings.js           # Configuration
├── package.json          # Dependencies
├── commands/             # All commands (100+)
│   ├── core/            # 16 commands
│   ├── group/           # 16 commands
│   ├── media/           # 12 commands
│   ├── downloader/      # 8 commands
│   ├── fun/             # 14 commands
│   ├── ai/              # 1 command
│   ├── textmaker/       # 17 commands
│   ├── search/          # 4 commands
│   ├── tools/           # 5 commands
│   └── owner/           # 5 commands
└── auth_info/           # Session data (auto-created)
```

## 💡 Pro Tips

1. **Keep dependencies updated:** `npm update`
2. **Use PM2 for 24/7:** `pm2 start index.js`
3. **Back up auth_info:** Contains your session
4. **Enable auto-restart:** Bot recovers from crashes
5. **Monitor logs:** Check for errors

## 🆘 Support

- 📢 **Channel:** https://whatsapp.com/channel/0029Vb88OB4545unOuID4H0Q
- 🎥 **YouTube:** VK911_TT
- 👑 **Owner:** GBEXCHANGE †

## 📝 Command List

Run `.menu` in WhatsApp to see all commands!

## 🎉 You're All Set!

Your VK911 BOT is ready to dominate WhatsApp! 🚀

Made with 💣 by **GBEXCHANGE †**
